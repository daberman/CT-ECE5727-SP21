/*
 * SWITCHCTL.h
 *
 *  Created on: Feb 2, 2018
 *      Author: cipi
 */

#ifndef SRC_AXIS_SWITCH_SWITCH_CTL_H_
#define SRC_AXIS_SWITCH_SWITCH_CTL_H_

#include "AXI_SWITCH.h"
#include "SW_GPIO.h"

class SWITCH_CTL {
public:
	SWITCH_CTL(AXI_SWITCH& src_axi_sw, AXI_SWITCH& dst_axi_sw, SWITCH_GPIO& gpio, uint16_t max_nr_ch, uint16_t default_pos):
		src_axi_sw_(src_axi_sw), dst_axi_sw_(dst_axi_sw), gpio_(gpio), nr_of_ch_(max_nr_ch-1), current_pos_(default_pos)
	{
		setChannel();
	}
	void setChannel()
	{
		uint16_t sw;

		sw = gpio_.readSwitchGpio();
		if(sw > nr_of_ch_)
		{
			sw = 0;
		}

		src_axi_sw_.changeMasterChannel(sw);
		dst_axi_sw_.changeSlaveChannel(sw);
	}
	void updateChannel()
	{
		uint16_t sw;

		sw = gpio_.readSwitchGpio();
		if(sw > nr_of_ch_)
		{
			sw = 0;
		}

		if(sw != current_pos_)
		{
			current_pos_ = sw;
			setChannel();
		}
	}
private:
	AXI_SWITCH& src_axi_sw_;
	AXI_SWITCH& dst_axi_sw_;
	SWITCH_GPIO& gpio_;
	uint16_t nr_of_ch_;
	uint16_t current_pos_;
};

#endif /* SRC_AXIS_SWITCH_SWITCH_CTL_H_ */
