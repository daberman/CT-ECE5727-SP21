/*
 * AXISWITCH.h
 *
 *  Created on: Feb 2, 2018
 *      Author: cipi
 */

#ifndef SRC_AXIS_SWITCH_AXI_SWITCH_H_
#define SRC_AXIS_SWITCH_AXI_SWITCH_H_

#include <stdexcept>

#include "xaxis_switch.h"

#define STRINGIZE(x) STRINGIZE2(x)
#define STRINGIZE2(x) #x
#define LINE_STRING STRINGIZE(__LINE__)

class AXI_SWITCH {
public:
	AXI_SWITCH(uint16_t dev_id) :
		drv_inst_()
	{
	    XAxis_Switch_Config *Config;
	    XStatus Status;

	    Config = XAxisScr_LookupConfig(dev_id);
		if (NULL == Config) {
			throw std::runtime_error(__FILE__ ":" LINE_STRING);
		}

		Status = XAxisScr_CfgInitialize(&drv_inst_, Config,
							Config->BaseAddress);
		if (Status != XST_SUCCESS) {
			throw std::runtime_error(__FILE__ ":" LINE_STRING);
		}
	}

	void changeSlaveChannel(uint8_t slave_ch)
	{
		XAxisScr_RegUpdateDisable(&drv_inst_);
		XAxisScr_MiPortDisableAll(&drv_inst_);
		XAxisScr_MiPortEnable(&drv_inst_, 0, slave_ch);
		XAxisScr_RegUpdateEnable(&drv_inst_);
	}

	void changeMasterChannel(uint8_t master_ch)
	{
		XAxisScr_RegUpdateDisable(&drv_inst_);
		XAxisScr_MiPortDisableAll(&drv_inst_);
		XAxisScr_MiPortEnable(&drv_inst_, master_ch, 0);
		XAxisScr_RegUpdateEnable(&drv_inst_);
	}

private:
	XAxis_Switch drv_inst_;
};

#endif /* SRC_AXIS_SWITCH_AXI_SWITCH_H_ */
