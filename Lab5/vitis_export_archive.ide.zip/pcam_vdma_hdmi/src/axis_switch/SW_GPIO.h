/*
 * SWITCHGPIO.h
 *
 *  Created on: Feb 2, 2018
 *      Author: cipi
 */

#ifndef SRC_AXIS_SWITCH_SW_GPIO_H_
#define SRC_AXIS_SWITCH_SW_GPIO_H_

#include "xgpio.h"
#include <stdexcept>

#define STRINGIZE(x) STRINGIZE2(x)
#define STRINGIZE2(x) #x
#define LINE_STRING STRINGIZE(__LINE__)

class SWITCH_GPIO {
public:
	SWITCH_GPIO(uint16_t dev_id) :
		drv_inst_()
	{
		XStatus Status;
		Status = XGpio_Initialize(&drv_inst_, dev_id);
		if (Status != XST_SUCCESS) {
			throw std::runtime_error(__FILE__ ":" LINE_STRING);
		}
		XGpio_SetDataDirection(&drv_inst_, 1, 1);
	}
	uint32_t readSwitchGpio()
	{
		return XGpio_DiscreteRead(&drv_inst_, 1);
	}
private:
	XGpio drv_inst_;
};

#endif /* SRC_AXIS_SWITCH_SW_GPIO_H_ */
